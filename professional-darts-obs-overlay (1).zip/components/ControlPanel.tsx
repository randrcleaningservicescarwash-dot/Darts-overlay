
import React, { useState } from 'react';
import { GameState, DartsAction } from '../types';

interface ControlPanelProps {
  state: GameState;
  dispatch: (action: DartsAction) => void;
  onClose: () => void;
  isStandalone?: boolean;
}

const ControlPanel: React.FC<ControlPanelProps> = ({ state, dispatch, isStandalone = false }) => {
  const [inputVal, setInputVal] = useState<string>('');
  const activePlayer = state.players[state.activePlayerIndex];

  const handleNumClick = (num: string) => {
    if (inputVal.length < 3) {
      const nextVal = inputVal + num;
      if (parseInt(nextVal) <= 180) {
        setInputVal(nextVal);
      }
    }
  };

  const handleClear = () => setInputVal('');

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    const score = parseInt(inputVal);
    if (!isNaN(score) && score >= 0 && score <= 180) {
      dispatch({ type: 'SUBTRACT_SCORE', amount: score });
      setInputVal('');
    }
  };

  const handleUndo = () => {
    dispatch({ type: 'UNDO' });
  };

  return (
    <div className={`bg-gray-900 text-white rounded-[2.5rem] shadow-2xl border border-white/10 overflow-hidden ${isStandalone ? 'w-full' : 'w-[400px]'}`}>
      <div className="p-8 space-y-8">
        {/* Active Player Status */}
        <div className="bg-gradient-to-br from-blue-600/20 to-blue-900/20 border border-blue-500/30 rounded-3xl p-6 flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-[10px] uppercase font-black text-blue-500 tracking-widest">Turn to throw</p>
            <h2 className="text-3xl font-black uppercase tracking-tighter">{activePlayer.name} {activePlayer.flag}</h2>
          </div>
          <div className="text-right">
            <p className="text-[10px] uppercase font-black text-blue-500 tracking-widest">Score</p>
            <p className="text-5xl font-black tracking-tighter">{activePlayer.score}</p>
          </div>
        </div>

        {/* Calculator Display */}
        <div className="relative group">
          <div className="absolute inset-0 bg-blue-500/5 blur-xl rounded-2xl group-hover:bg-blue-500/10 transition-all" />
          <div className="relative bg-black/60 border-2 border-white/5 rounded-3xl p-6 flex flex-col items-center">
             <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">Subtract Points</span>
             <div className="text-6xl font-black text-white h-16 flex items-center justify-center">
                {inputVal || <span className="text-gray-800">000</span>}
             </div>
          </div>
        </div>

        {/* Numpad */}
        <div className="grid grid-cols-3 gap-3">
          {['7', '8', '9', '4', '5', '6', '1', '2', '3', 'CLR', '0', 'OK'].map((key) => {
            const isOk = key === 'OK';
            const isClr = key === 'CLR';
            return (
              <button
                key={key}
                onClick={() => {
                  if (isOk) handleSubmit();
                  else if (isClr) handleClear();
                  else handleNumClick(key);
                }}
                className={`h-16 rounded-2xl text-2xl font-black transition-all active:scale-95 shadow-lg border border-white/5 
                  ${isOk ? 'bg-blue-600 hover:bg-blue-500 text-white col-span-1' : 
                    isClr ? 'bg-red-500/10 text-red-500 hover:bg-red-500/20' : 
                    'bg-gray-800 hover:bg-gray-700 text-gray-300'}`}
              >
                {key}
              </button>
            );
          })}
        </div>

        {/* Quick Buttons & Undo */}
        <div className="flex gap-3">
          <button 
            onClick={handleUndo}
            className="flex-1 bg-gray-800 hover:bg-gray-700 border border-white/5 py-4 rounded-2xl font-black text-xs uppercase tracking-widest text-gray-400 flex items-center justify-center gap-2"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6" /></svg>
            Undo Last
          </button>
          <button 
            onClick={() => dispatch({ type: 'NEXT_LEG' })}
            className="flex-1 bg-green-500/10 hover:bg-green-500/20 text-green-500 border border-green-500/20 py-4 rounded-2xl font-black text-xs uppercase tracking-widest"
          >
            New Leg
          </button>
        </div>

        {/* Setup Config */}
        <div className="pt-6 border-t border-white/5 space-y-4">
           <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Match Title</label>
                <input 
                  className="w-full bg-gray-800/50 border border-white/5 px-3 py-2 rounded-xl text-xs font-bold" 
                  value={state.matchTitle} 
                  onChange={(e) => dispatch({ type: 'UPDATE_CONFIG', data: { matchTitle: e.target.value } })}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Tournament</label>
                <input 
                  className="w-full bg-gray-800/50 border border-white/5 px-3 py-2 rounded-xl text-xs font-bold" 
                  value={state.tournamentInfo} 
                  onChange={(e) => dispatch({ type: 'UPDATE_CONFIG', data: { tournamentInfo: e.target.value } })}
                />
              </div>
           </div>
           
           <div className="space-y-3">
              <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Edit Names & Flags</p>
              {state.players.map((p, i) => (
                <div key={i} className="flex gap-2 items-center bg-black/20 p-2 rounded-2xl">
                  <input 
                    className="flex-1 bg-transparent text-sm font-bold p-1 focus:outline-none" 
                    value={p.name} 
                    onChange={(e) => dispatch({ type: 'UPDATE_PLAYER', index: i, data: { name: e.target.value } })}
                  />
                  <input 
                    className="w-10 bg-transparent text-lg text-center p-1 focus:outline-none" 
                    value={p.flag} 
                    onChange={(e) => dispatch({ type: 'UPDATE_PLAYER', index: i, data: { flag: e.target.value } })}
                  />
                  <div className="flex bg-gray-800 rounded-lg p-1">
                     <button onClick={() => dispatch({ type: 'UPDATE_PLAYER', index: i, data: { legs: Math.max(0, p.legs - 1) } })} className="px-2 font-bold">-</button>
                     <span className="px-2 font-black text-blue-500">{p.legs}</span>
                     <button onClick={() => dispatch({ type: 'UPDATE_PLAYER', index: i, data: { legs: p.legs + 1 } })} className="px-2 font-bold">+</button>
                  </div>
                </div>
              ))}
           </div>
        </div>
      </div>
    </div>
  );
};

export default ControlPanel;

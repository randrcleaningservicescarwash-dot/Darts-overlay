
import React, { useEffect, useState } from 'react';
import { GameState } from '../types';
import { getCheckoutSuggestion } from '../services/geminiService';

interface ScoreboardProps {
  state: GameState;
}

const Scoreboard: React.FC<ScoreboardProps> = ({ state }) => {
  const { players, activePlayerIndex, matchTitle, tournamentInfo } = state;
  const [checkout, setCheckout] = useState<string>("");

  const activePlayer = players[activePlayerIndex];
  const legWinnerIdx = players.findIndex(p => p.score === 0);
  const isWinner = legWinnerIdx !== -1;

  useEffect(() => {
    if (activePlayer.score <= 170 && activePlayer.score > 1 && !isWinner) {
      getCheckoutSuggestion(activePlayer.score).then(setCheckout);
    } else {
      setCheckout("");
    }
  }, [activePlayer.score, isWinner]);

  return (
    <div className="broadcast-shadow flex flex-col w-[600px] select-none scale-[1.2] lg:scale-[1.7] transform origin-bottom transition-all duration-500">
      {/* Checkout Suggestion Banner */}
      <div className={`transition-all duration-500 ease-out overflow-hidden ${checkout && !isWinner ? 'max-h-16 mb-2 opacity-100 translate-y-0' : 'max-h-0 opacity-0 translate-y-4'}`}>
         <div className="bg-[#39FF14] text-black px-6 py-3 flex items-center justify-between font-black italic shadow-2xl border-l-[8px] border-black">
            <span className="text-[10px] uppercase tracking-[0.3em] opacity-80">Route to Out</span>
            <span className="text-2xl tracking-tighter uppercase font-black">{checkout}</span>
         </div>
      </div>

      {/* Header Bar */}
      <div className="bg-[#0f0f0f] text-[#888888] px-6 py-3 text-[10px] font-black uppercase tracking-[0.3em] flex justify-between items-center border-b border-white/5 rounded-t-lg">
        <span className="flex items-center gap-3">
          <div className="w-2.5 h-2.5 bg-red-600 rounded-full shadow-[0_0_10px_rgba(220,38,38,0.8)] animate-pulse" />
          {matchTitle}
        </span>
        <span className="text-[#444444]">LEGS</span>
      </div>

      {/* Players Section */}
      <div className="flex flex-col bg-[#111111]">
        {players.map((player, idx) => {
          const isCurrent = activePlayerIndex === idx && !isWinner;
          const hasWon = player.score === 0;

          return (
            <div key={idx} className="flex h-20 relative overflow-hidden">
              {/* Background states */}
              <div className={`absolute inset-0 transition-opacity duration-700 ${isCurrent ? 'opacity-100' : 'opacity-0'}`}>
                 <div className="absolute inset-0 bg-gradient-to-r from-blue-600/30 via-blue-600/5 to-transparent" />
              </div>
              <div className={`absolute inset-0 transition-opacity duration-1000 ${hasWon ? 'opacity-100' : 'opacity-0'}`}>
                 <div className="absolute inset-0 bg-gradient-to-r from-[#39FF14]/20 via-[#39FF14]/5 to-transparent" />
              </div>

              {/* Status Indicator Bar */}
              <div className={`absolute left-0 top-0 bottom-0 w-2 transition-all duration-500 z-10 
                ${hasWon ? 'bg-[#39FF14]' : isCurrent ? 'bg-blue-500 shadow-[4px_0_15px_rgba(59,130,246,0.5)]' : 'bg-transparent'}`} 
              />
              
              {/* Player Identity */}
              <div className={`flex-1 flex items-center px-8 transition-colors duration-500 ${idx === 0 ? 'bg-white border-b border-gray-100' : 'bg-[#fafafa]'}`}>
                <div className="flex flex-col">
                  <span className={`text-3xl font-black uppercase tracking-tighter leading-none 
                    ${hasWon ? 'text-black' : isCurrent ? 'text-black' : 'text-gray-400'}`}>
                    {player.name}
                  </span>
                  {hasWon && (
                    <span className="text-[#39FF14] text-xs font-black italic uppercase tracking-widest mt-1 animate-pulse bg-black px-2 py-0.5 rounded w-fit">
                      Winner
                    </span>
                  )}
                </div>
                
                {isCurrent && (
                  <div className="ml-6 flex gap-1.5 items-center">
                    <div className="w-2.5 h-2.5 bg-blue-500 rounded-full animate-bounce [animation-delay:-0.3s]" />
                    <div className="w-2.5 h-2.5 bg-blue-500 rounded-full animate-bounce [animation-delay:-0.15s]" />
                    <div className="w-2.5 h-2.5 bg-blue-500 rounded-full animate-bounce" />
                  </div>
                )}
                
                <div className="ml-auto text-5xl drop-shadow-md transform group-hover:scale-110 transition-transform">{player.flag}</div>
              </div>

              {/* Legs Display */}
              <div className="w-24 bg-[#0a0a0a] text-white flex items-center justify-center text-5xl font-black border-r border-white/5 border-l border-white/5">
                {player.legs}
              </div>

              {/* Score Display */}
              <div className="w-32 bg-[#000000] flex items-center justify-center">
                <span className={`text-6xl font-black tracking-tighter transition-all duration-300
                  ${hasWon ? 'text-[#39FF14] scale-90' : player.score <= 170 && player.score > 0 ? 'text-[#39FF14]' : 'text-white'}`}>
                  {player.score}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Broadcast Footer */}
      <div className="bg-[#000000] text-white px-6 py-4 flex justify-between items-center rounded-b-lg shadow-2xl">
        <div className="flex flex-col">
          <span className="text-[10px] font-black uppercase text-[#666666] tracking-[0.4em] mb-1">
            {tournamentInfo}
          </span>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex flex-col items-end leading-none">
            <span className="text-[10px] font-black text-blue-500 tracking-[0.2em] italic">ULTRA HD</span>
            <span className="text-[9px] font-bold text-[#444444] tracking-tighter">120 FPS SOURCE</span>
          </div>
          <div className="w-px h-8 bg-white/10" />
          <div className="bg-white text-black px-3 py-1 text-[11px] font-black rounded italic tracking-tighter">
            SKY SPORTS
          </div>
        </div>
      </div>
    </div>
  );
};

export default Scoreboard;

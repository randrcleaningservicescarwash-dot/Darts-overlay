
import { GoogleGenAI } from "@google/genai";

// Local fallback for common professional checkouts (170 down to 2)
const CHECKOUT_FALLBACK: Record<number, string> = {
  170: "T20, T20, BULL",
  167: "T20, T19, BULL",
  164: "T20, T18, BULL",
  161: "T20, T17, BULL",
  160: "T20, T20, D20",
  158: "T20, T20, D19",
  141: "T20, T19, D12",
  121: "T20, 11, D25",
  100: "T20, D20",
  80: "T20, D10",
  60: "20, D20",
  40: "D20",
  32: "D16",
  16: "D8",
};

export async function getCheckoutSuggestion(score: number): Promise<string> {
  if (score > 170 || score < 2) return "";

  // Always return local fallback immediately if available for critical fast scores
  if (CHECKOUT_FALLBACK[score]) return CHECKOUT_FALLBACK[score];

  const apiKey = process.env.API_KEY;
  if (!apiKey || apiKey === "undefined") {
     // If no API key, we just rely on standard patterns if needed or return empty
     return CHECKOUT_FALLBACK[score] || "";
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Pro darts checkout for ${score}. Sequence only (e.g. T20, T19, D12). 3 darts max. If no out, return empty.`,
      config: { thinkingConfig: { thinkingBudget: 0 } }
    });
    return response.text?.trim() || "";
  } catch (error) {
    console.error("Gemini Suggestion Error:", error);
    return CHECKOUT_FALLBACK[score] || "";
  }
}
